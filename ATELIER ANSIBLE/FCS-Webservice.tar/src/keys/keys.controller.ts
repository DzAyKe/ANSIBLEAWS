import { Body, Controller, Delete, Get, Param, Post } from '@nestjs/common';
import { KeysService } from './keys.service';
import { CreateKeyDto } from './dto/create-key.dto';
import { ApiBearerAuth } from '@nestjs/swagger';

@Controller('keys')
@ApiBearerAuth()
export class KeysController {
  constructor(private readonly keysService: KeysService) {
  }

  @Post()
  create(@Body() createKeyDto: CreateKeyDto) {
    return this.keysService.create(createKeyDto);
  }

  @Get(':name')
  findOne(@Param('name') name: string) {
    return this.keysService.findOne(name);
  }

  @Delete(':name')
  remove(@Param('name') name: string) {
    return this.keysService.remove(name);
  }
}
