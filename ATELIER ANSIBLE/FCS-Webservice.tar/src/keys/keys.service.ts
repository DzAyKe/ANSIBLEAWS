import { BadRequestException, Injectable, InternalServerErrorException, Logger } from '@nestjs/common';
import { CreateKeyDto } from './dto/create-key.dto';
import { SecretClient } from '@azure/keyvault-secrets';
import { DefaultAzureCredential } from '@azure/identity';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class KeysService {

  private readonly logger = new Logger(KeysService.name);

  private readonly client: SecretClient | null;

  constructor(configService: ConfigService) {
    const credential = new DefaultAzureCredential();

    const keyVaultUrl = configService.get<string>('keyVaultUri');
    if (!keyVaultUrl) this.logger.warn('KEY_VAULT_URI is empty');
    else {
      this.client = new SecretClient(keyVaultUrl, credential);
    }
  }

  create(createKeyDto: CreateKeyDto) {
    if (!this.client) {
      throw new InternalServerErrorException("No key vault uri provided")
    }
     try {
       return this.client.setSecret(
         createKeyDto.name,
         createKeyDto.value,
       );
     } catch (e) {
       throw new BadRequestException("failed to create a new secret")
     }
  }

  findOne(name: string) {
    if (!this.client) {
      throw new InternalServerErrorException("No key vault uri provided")
    }
    try {
      return this.client.getSecret(name);
    } catch (e: any) {
      throw new BadRequestException("failed to find a secret by name")
    }
  }

  async remove(name: string) {
    if (!this.client) {
      throw new InternalServerErrorException("No key vault uri provided")
    }
    try {
      const deletePoller = await this.client.beginDeleteSecret(name);
      await deletePoller?.pollUntilDone();
    } catch (e) {
      throw new BadRequestException("failed to remove secret by name")
    }
  }
}
