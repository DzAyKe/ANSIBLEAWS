import { Test, TestingModule } from '@nestjs/testing';
import { KeysService } from './keys.service';
import { ConfigService } from '@nestjs/config';

const configurationMock = {
  get: jest.fn((key: string) => {
    if (key === 'keyVaultUri') {
      return 'https://my_key_vault';
    }
    return undefined;
  }),
};

describe('KeysService', () => {
  let service: KeysService;
  let configService: ConfigService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        KeysService,
        { provide: ConfigService, useValue: configurationMock },
      ],
    }).compile();

    service = module.get<KeysService>(KeysService);
    configService = module.get<ConfigService>(ConfigService);
  });

  it('should be defined', () => {
    jest.spyOn(configService, 'get').mockReturnValueOnce(undefined);
    expect(service).toBeDefined();
  });
});
