import { Test, TestingModule } from '@nestjs/testing';
import { UsersController } from './users.controller';
import { UsersService } from './users.service';
import { Types } from 'mongoose';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';

const usersServiceMock = {
  create: jest.fn(),
  findAll: jest.fn(),
  findOne: jest.fn(),
  update: jest.fn(),
  delete: jest.fn(),
};

describe('UsersController', () => {
  let controller: UsersController;
  let service: jest.Mocked<UsersService>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [UsersController],
      providers: [{ provide: UsersService, useValue: usersServiceMock }],
    }).compile();

    controller = module.get<UsersController>(UsersController);
    service = module.get(UsersService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('create', () => {
    it('should create a new user', async () => {
      const mockedUser = {
        _id: new Types.ObjectId(),
        email: 'Email #1',
        password: 'Password #1',
        __v: '0'
      };
      service.create.mockResolvedValueOnce(mockedUser);

      const createUserDto: CreateUserDto = {
        email: 'Email #1',
        password: 'Password #1',
      };
      const result = await controller.create(createUserDto);

      expect(result).toEqual(mockedUser);
      expect(service.create).toHaveBeenCalledWith(createUserDto);
    });
  });

  describe('findAll', () => {
    it('should return an array of users', async () => {
      const mockedUsers = [
        {
          _id: new Types.ObjectId(),
          email: 'Email #1',
          password: 'Password #1',
        },
        {
          _id: new Types.ObjectId(),
          email: 'Email #2',
          password: 'Password #2',
        },
        {
          _id: new Types.ObjectId(),
          email: 'Email #3',
          password: 'Password #3',
        },
      ];
      service.findAll.mockResolvedValueOnce(mockedUsers);

      const result = await controller.findAll();

      expect(result).toEqual(mockedUsers);
      expect(service.findAll).toHaveBeenCalled();
    });
  });

  describe('findOne', () => {
    it('should return a single user', async () => {
      const mockedUser = {
        _id: new Types.ObjectId(),
        email: 'Email #1',
        password: 'Password #1',
      };
      service.findOne.mockResolvedValueOnce(mockedUser as any);

      const id = new Types.ObjectId().toString();
      const result = await controller.findOne(id);

      expect(result).toEqual(mockedUser);
      expect(service.findOne).toHaveBeenCalledWith(id);
    });
  });

  describe('update', () => {
    it('should update a single user', async () => {
      const mockedUser = {
        _id: new Types.ObjectId(),
        email: 'Email #1'
      };
      service.update.mockResolvedValueOnce(mockedUser as any);

      const id = new Types.ObjectId().toString();
      const updateUserDto: UpdateUserDto = {
        email: 'Email #1'
      };
      const result = await controller.update(id, updateUserDto);

      expect(result).toEqual(mockedUser);
      expect(service.update).toHaveBeenCalledWith(id, updateUserDto);
    });
  });

  describe('delete', () => {
    it('should delete a single user', async () => {
      const mockedUser = {
        _id: new Types.ObjectId(),
        email: 'Email #1',
        password: 'Password #1',
      };
      service.delete.mockResolvedValueOnce(mockedUser as any);

      const id = new Types.ObjectId().toString();
      const result = await controller.delete(id);

      expect(result).toEqual(mockedUser);
      expect(service.delete).toHaveBeenCalledWith(id);
    });
  });
});
