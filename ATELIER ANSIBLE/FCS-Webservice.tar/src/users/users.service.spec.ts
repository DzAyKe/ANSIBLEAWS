import { Test, TestingModule } from '@nestjs/testing';
import { UsersService } from './users.service';
import { Model, Types } from 'mongoose';
import { User } from './schemas/user.schema';
import { getModelToken } from '@nestjs/mongoose';
import { CreateUserDto } from './dto/create-user.dto';
import * as bcrypt from 'bcrypt';

const userModelMock = {
  create: jest.fn(),
  find: jest.fn(),
  findOne: jest.fn(),
  findByIdAndUpdate: jest.fn(),
  findByIdAndDelete: jest.fn(),
};

describe('UsersService', () => {
  let service: UsersService;
  let model: jest.Mocked<Model<User>>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        UsersService,
        { provide: getModelToken('User'), useValue: userModelMock },
      ],
    }).compile();

    service = module.get<UsersService>(UsersService);
    model = module.get(getModelToken('User'));
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('create', () => {
    it('should insert a new user with hashed password', async () => {
      const mockedUser = {
        email: 'Email #1',
        password: 'hashedPassword',
      };
      model.create.mockResolvedValueOnce(mockedUser as any);

      (bcrypt.genSalt as jest.Mock) = jest.fn().mockResolvedValueOnce('salt');
      const bcryptHash = jest.fn().mockResolvedValueOnce(mockedUser.password);
      (bcrypt.hash as jest.Mock) = bcryptHash;

      const createUserDto: CreateUserDto = {
        email: 'Email #1',
        password: 'Password #1',
      };
      const result = await service.create(createUserDto);

      expect(result).toEqual(mockedUser);
      expect(model.create).toHaveBeenCalledWith(mockedUser);
      expect(bcryptHash).toHaveBeenCalledWith(createUserDto.password, 'salt');
    });
  });

  describe('findAll', () => {
    it('should return all users', async () => {
      const mockedUsers = [
        {
          email: 'Email #1',
          password: 'Password #1',
        },
        {
          email: 'Email #2',
          password: 'Password #2',
        },
      ];
      model.find.mockReturnValueOnce({
        exec: jest.fn().mockResolvedValueOnce(mockedUsers),
      } as any);

      const result = await service.findAll();

      expect(result).toEqual(mockedUsers);
      expect(model.find).toHaveBeenCalled();
    });
  });

  describe('findOne', () => {
    it('should return one user', async () => {
      const mockedUser = {
        email: 'Email #1',
        password: 'Password #1',
      };
      model.findOne.mockReturnValueOnce({
        exec: jest.fn().mockResolvedValueOnce(mockedUser),
      } as any);

      const id = new Types.ObjectId().toString();
      const result = await service.findOne(id);

      expect(result).toEqual(mockedUser);
      expect(model.findOne).toHaveBeenCalledWith({ _id: id });
    });
  });

  describe('findOneByEmail', () => {
    it('should return one user', async () => {
      const email = 'Email #1';

      const mockedUser = {
        email: email,
        password: 'Password #1',
      };
      model.findOne.mockReturnValueOnce({
        exec: jest.fn().mockResolvedValueOnce(mockedUser),
      } as any);

      const result = await service.findOneByEmail(email);

      expect(result).toEqual(mockedUser);
      expect(model.findOne).toHaveBeenCalledWith({ email: email });
    });
  });

  describe('update', () => {
    it('should update a user', async () => {
      const mockedUser = {
        email: 'Email #1',
        password: 'Password #1',
      };
      model.findByIdAndUpdate.mockReturnValueOnce({
        exec: jest.fn().mockResolvedValueOnce(mockedUser),
      } as any);

      const id = new Types.ObjectId().toString();
      const updateUserDto = {
        email: 'Email #1',
        password: 'Password #1',
      };
      const result = await service.update(id, updateUserDto);

      expect(result).toEqual(mockedUser);
      expect(model.findByIdAndUpdate).toHaveBeenCalledWith(
        { _id: id },
        updateUserDto,
        { new: true },
      );
    });
  });

  describe('delete', () => {
    it('should delete au user', async () => {
      const mockedUser = {
        email: 'Email #1',
        password: 'Password #1',
      };
      model.findByIdAndDelete.mockReturnValueOnce({
        exec: jest.fn().mockResolvedValueOnce(mockedUser),
      } as any);

      const id = new Types.ObjectId().toString();
      const result = await service.delete(id);

      expect(result).toEqual(mockedUser);
      expect(model.findByIdAndDelete).toHaveBeenCalledWith({ _id: id });
    });
  });
});
