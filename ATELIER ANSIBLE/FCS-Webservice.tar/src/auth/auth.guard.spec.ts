import { Test, TestingModule } from '@nestjs/testing';
import { AuthGuard } from './auth.guard';
import { JwtService } from '@nestjs/jwt';
import { Reflector } from '@nestjs/core';
import { IS_PUBLIC_KEY } from './decorators/public.decorator';
import { UnauthorizedException } from '@nestjs/common';

const jwtServiceMock = {
  verifyAsync: jest.fn(),
};

const reflectorMock = {
  getAllAndOverride: jest.fn(),
};

describe('AuthGuard', () => {
  let guard: AuthGuard;
  let jwtService: jest.Mocked<JwtService>;
  let reflector: jest.Mocked<Reflector>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthGuard,
        { provide: JwtService, useValue: jwtServiceMock },
        { provide: Reflector, useValue: reflectorMock },
      ],
    }).compile();

    guard = module.get<AuthGuard>(AuthGuard);
    jwtService = module.get(JwtService);
    reflector = module.get(Reflector);
  });

  it('should be defined', () => {
    expect(guard).toBeDefined();
  });

  describe('canActivate', () => {
    it('should return true on public routes', async () => {
      const mockedContext = {
        getClass: jest.fn(),
        getHandler: jest.fn(),
        switchToHttp: jest.fn(() => ({
          getRequest: jest.fn().mockReturnValue({
            headers: {
              authorization: 'Bearer JWT#1',
            },
          }),
        })),
      } as any;
      reflector.getAllAndOverride.mockReturnValueOnce(true as never);

      const result = await guard.canActivate(mockedContext);

      expect(result).toEqual(true);
      expect(reflector.getAllAndOverride).toHaveBeenCalledWith(IS_PUBLIC_KEY, [
        mockedContext.getHandler(),
        mockedContext.getClass(),
      ]);
    });

    it('should block non bearer tokens', async () => {
      const mockedContext = {
        getClass: jest.fn(),
        getHandler: jest.fn(),
        switchToHttp: jest.fn(() => ({
          getRequest: jest.fn().mockReturnValue({
            headers: {
              authorization: 'Auth JWT#1',
            },
          }),
        })),
      } as any;
      reflector.getAllAndOverride.mockReturnValueOnce(false as never);

      const result = async () => {
        await guard.canActivate(mockedContext);
      };

      await expect(result()).rejects.toThrow(UnauthorizedException);
      expect(reflector.getAllAndOverride).toHaveBeenCalledWith(IS_PUBLIC_KEY, [
        mockedContext.getHandler(),
        mockedContext.getClass(),
      ]);
    });
  });

  it('should block if user is not verified', async () => {
    const mockedContext = {
      getClass: jest.fn(),
      getHandler: jest.fn(),
      switchToHttp: jest.fn(() => ({
        getRequest: jest.fn().mockReturnValue({
          headers: {
            authorization: 'Bearer JWT#1',
          },
        }),
      })),
    } as any;
    reflector.getAllAndOverride.mockReturnValueOnce(false as never);
    jwtService.verifyAsync.mockRejectedValueOnce({});

    const result = async () => {
      await guard.canActivate(mockedContext);
    };

    await expect(result()).rejects.toThrow(UnauthorizedException);
    expect(reflector.getAllAndOverride).toHaveBeenCalledWith(IS_PUBLIC_KEY, [
      mockedContext.getHandler(),
      mockedContext.getClass(),
    ]);
    expect(jwtService.verifyAsync).toHaveBeenCalledWith('JWT#1');
  });

  it('should pass if user is verified', async () => {
    const mockedContext = {
      getClass: jest.fn(),
      getHandler: jest.fn(),
      switchToHttp: jest.fn(() => ({
        getRequest: jest.fn().mockReturnValue({
          headers: {
            authorization: 'Bearer JWT#1',
          },
        }),
      })),
    } as any;
    reflector.getAllAndOverride.mockReturnValueOnce(false as never);
    jwtService.verifyAsync.mockResolvedValueOnce(true as any);

    const result = await guard.canActivate(mockedContext);

    expect(result).toEqual(true);
    expect(reflector.getAllAndOverride).toHaveBeenCalledWith(IS_PUBLIC_KEY, [
      mockedContext.getHandler(),
      mockedContext.getClass(),
    ]);
    expect(jwtService.verifyAsync).toHaveBeenCalledWith('JWT#1');
  });
});
