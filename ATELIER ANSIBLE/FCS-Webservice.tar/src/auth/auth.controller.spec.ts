import { Test, TestingModule } from '@nestjs/testing';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { LoginUserDto } from './dto/login-user.dto';

const authServiceMock = {
  login: jest.fn(),
};

describe('AuthController', () => {
  let controller: AuthController;
  let service: jest.Mocked<AuthService>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [AuthController],
      providers: [{ provide: AuthService, useValue: authServiceMock }],
    }).compile();

    controller = module.get<AuthController>(AuthController);
    service = module.get(AuthService);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  describe('login', () => {
    it('should login user', async () => {
      const mockedToken = {
        access_token: 'JWT #1',
      };
      service.login.mockResolvedValueOnce(mockedToken);

      const loginUserDto: LoginUserDto = {
        email: 'Username #1',
        password: 'Password #1',
      };
      const result = await controller.login(loginUserDto);

      expect(result).toEqual(mockedToken);
      expect(service.login).toHaveBeenCalledWith(loginUserDto);
    });
  });
});
