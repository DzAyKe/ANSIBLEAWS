import { Test, TestingModule } from '@nestjs/testing';
import { AuthService } from './auth.service';
import { UsersService } from '../users/users.service';
import { JwtService } from '@nestjs/jwt';
import { LoginUserDto } from './dto/login-user.dto';
import { UnauthorizedException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';

const usersServiceMock = {
  findOneByEmail: jest.fn(),
};

const jwtServiceMock = {
  signAsync: jest.fn(),
};

describe('AuthService', () => {
  let service: AuthService;
  let usersService: jest.Mocked<UsersService>;
  let jwtService: jest.Mocked<JwtService>;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        { provide: UsersService, useValue: usersServiceMock },
        { provide: JwtService, useValue: jwtServiceMock },
      ],
    }).compile();

    service = module.get<AuthService>(AuthService);
    usersService = module.get(UsersService);
    jwtService = module.get(JwtService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  describe('login', () => {
    it('should login a valid user', async () => {
      const mockedUser = {
        _id: '#1',
        email: 'Email #1',
        password: 'Password #1',
      };
      usersService.findOneByEmail.mockResolvedValueOnce(mockedUser as any);
      const mockedJwt = {
        access_token: 'JWT #1',
      };
      jwtService.signAsync.mockResolvedValueOnce(mockedJwt.access_token);
      (bcrypt.compare as jest.Mock) = jest.fn().mockResolvedValue(true);

      const loginUserDto: LoginUserDto = {
        email: 'Email #1',
        password: 'Password #1',
      };
      const result = await service.login(loginUserDto);

      expect(result).toEqual(mockedJwt);
      expect(usersService.findOneByEmail).toHaveBeenCalledWith(
        mockedUser.email,
      );
      expect(jwtService.signAsync).toHaveBeenCalledWith({
        sub: mockedUser._id,
        username: mockedUser.email,
      });
    });

    it('should not login an invalid user', async () => {
      const mockedUser = {
        _id: '#1',
        email: 'Email #1',
        password: 'Password #2',
      };
      usersService.findOneByEmail.mockResolvedValueOnce(mockedUser as any);
      (bcrypt.compare as jest.Mock) = jest
        .fn()
        .mockRejectedValueOnce(new Error());

      const loginUserDto: LoginUserDto = {
        email: 'Email #1',
        password: 'Password #1',
      };
      const result = async () => {
        await service.login(loginUserDto);
      };

      await expect(result()).rejects.toThrow(UnauthorizedException);
      expect(usersService.findOneByEmail).toHaveBeenCalledWith(
        mockedUser.email,
      );
    });
  });
});
