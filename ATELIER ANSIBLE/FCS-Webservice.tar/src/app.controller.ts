import { Controller, Get, Res } from '@nestjs/common';
import { Public } from './auth/decorators/public.decorator';
import { ApiExcludeEndpoint } from '@nestjs/swagger';

@Controller()
export class AppController {

  @Public()
  @Get()
  @ApiExcludeEndpoint()
  redirect(@Res() res: any) {
    return res.redirect('/api');
  }
}
