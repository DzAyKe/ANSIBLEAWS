import * as process from 'node:process';

export default () => ({
  port: parseInt(process.env.PORT ?? '3000') || 3000,
  jwt: process.env.JWT_SECRET ?? 'myawesomesecret',
  mongodbUri:
    process.env.MONGODB_URI ?? 'mongodb://fake_cloud_society:fake_cloud_society@54.37.227.50:27017/fake_cloud_society',
  keyVaultUri: undefined,
});
