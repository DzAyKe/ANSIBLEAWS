# Fake Cloud Society Webservice
- Ce projet est un webservice basique fait avec [NestJs](https://nestjs.com) et [MongoDB](https://www.mongodb.com).
- Il expose une API avec des utilisateurs et une authentification [JWT](https://jwt.io).

## Sommaire
* [Installation](#Installation)
* [Development](#Development)
* [Production](#Production)
* [Déploiement](#Déploiement)
* [Configuration](#Configuration)

## Installation
1. Installer [node 22.14.0](https://nodejs.org/fr)
> Si vous avez besoin de faire cohabiter plusieurs versions de node vous pouvez utiliser [nvm](https://github.com/nvm-sh/nvm) 
2. Installer les dépendances (commande à exécuter dans le dossier Showcase-Website)
```
npm install
```
3. Je recommande vivement l'installation de mongodb via [docker](https://docs.docker.com/get-started/get-docker/) pour démarrer le serveur localement
```
docker run --name mongodb -p 27017:27017 -d mongodb/mongodb-community-server:latest
```

## Environment
Vous devez spécifier un fichier d'environnement :
```
MONGODB_URI=mongodb://localhost/fake_cloud_society
JWT_SECRET=myawesomesecret
```
See [.env.example](.env.example)

## Development
### Pré-requis :
1. Installer les dépendances
2. Avoir une instance de MongoDB par défaut tournant sur la machine
### Démarrage de l'instance
1. Démarrer le serveur en développement
```
npm run start:dev
```
2. Ouvrir l'URL [http://localhost:3000](http://localhost:3000)

## Production
1. Build du projet
```
npm run build
```
2. Démarrer le serveur en production avec
```
npm run start:prod
```
3. Ouvrir l'url [http://localhost:3000](http://localhost:3000)

## Déploiement
### Azure deployment
#### Préparation de l'environnement
1. Open [azure](https://azure.microsoft.com/fr-fr) and connect
2. Vous devez avoir un [abonnement](https://learn.microsoft.com/fr-fr/azure/cost-management-billing/manage/create-subscription) active sur azure. Tout ce qu'on fait dans ce cours est GRATUIT, rien ne vous sera facturé si vous avez déjà atteint la limite de crédit azure gratuit.
3. Installer [azure cli](https://learn.microsoft.com/fr-fr/cli/azure/install-azure-cli)
4. S'authentifier avec le CLI et suivre les instructions dans le terminal :
```
az login
```
#### Création d'une App sur azure
1. Ouvrir le service "App Service", vous pouvez le chercher dans la barre de recherche
2. Cliquer sur "Créer" en haut à gauche de l'écran puis sélectionner "Application Web"
3. Remplir les champs comme suit :

| Champ                  | Valeur                                                            |
|------------------------|-------------------------------------------------------------------|
| Abonnement             | L'abonnement créé ci-dessus                                       |
| Groupe de ressources   | Choisir un groupe de ressource ou en créer un                     |
| Nom                    | Ce que vous voulez                                                |
| Publier                | Code                                                              |
| Pile d'exécution       | Node 22 LTS                                                       |
| Système d'exploitation | Linux                                                             |
| Région                 | France Central                                                    |
| Plan Linux             | Par défaut, créer si rien de proposé au bout de quelques secondes |
| Plan tarification      | Gratuit (60 minutes processeur/jour)                              |

4. Vérifier + créer, nous laissons tous les autres paramètres par défaut
#### Déploiement de l'application
1. Installer les dépendances
```
npm install
```
2. Build du projet
```
npm run build
```
2. Récupération des variables d'environnement à partir du cli azure
```
export APPNAME=$(az webapp list --query "[0].name" --output tsv)
export APPRG=$(az webapp list --query "[0].resourceGroup" --output tsv)
export APPPLAN=$(az appservice plan list --query "[0].name" --output tsv)
export APPSKU=$(az appservice plan list --query "[0].sku.name" --output tsv)
export APPRUNTIME="node|22-LTS"
export APPLOCATION=$(az appservice plan list --query "[0].location" --output tsv)
```
3. Déploiement de l'application
```
az webapp up --name $APPNAME --resource-group $APPRG --plan $APPPLAN --sku $APPSKU --runtime $APPRUNTIME --location "$APPLOCATION"
```
4. L'URL de déploiement du projet est visible dans l'output du terminal
5. Un utilisateur est déjà créé
```
{
  "email": "john.doe@mail.test",
  "password": "test"
}
```
6. Libre à vous de créer d'autres utilisateurs et naviguer dans l'API !

## Configuration
### Fichier de configuration
Les paramètres de configuration de l'application sont visibles dans le fichier [src/config/configuration.ts](src/config/configuration.ts)
- L'URI MongoDB de développement est : mongodb://localhost/fake_cloud_society
- L'URI MongoDB de production est : mongodb://fake_cloud_society:fake_cloud_society@54.37.227.50:27017/fake_cloud_society

### Configurer Azure Key Vault
1. Récupérer le nom de votre groupe de ressource créé lors du déploiement
```
export APPRG=$(az webapp list --query "[0].resourceGroup" --output tsv)
```
2. Créer un keyvault azure :
```
az keyvault create --name <your-unique-keyvault-name> --resource-group $APPRG
```
3. Donner les accès de votre key vault à votre utilisateur
```
az role assignment create --role "Key Vault Secrets Officer" --assignee "<upn>" --scope "<scope>"
```
> Votre ***upn*** est votre email de connexion

> ***scope*** représente l'ID du vault reçu en 2.
4. Récupérez l'URI du Key Vault et placez-le dans le fichier [src/config/configuration.ts](src/config/configuration.ts)
5. Vous pouvez utiliser l'API /keys du projet pour créer, lire et supprimer des clés de votre Key Vault.

### Permettre à l'application déployée d'utiliser votre Key Vault
1. Récupérez le nom de l'application et votre groupe de ressource
```
export APPNAME=$(az webapp list --query "[0].name" --output tsv)
export APPRG=$(az webapp list --query "[0].resourceGroup" --output tsv)
```
2. Créez une identité d'application
```
az webapp identity assign --name $APPNAME --resource-group $APPRG
```
3. Dans l'output précédent, notez le principalId
4. Récupérez l'ID de votre Key Vault
```
export KEYVAULT=$(az keyvault list --query "[0].name" --output tsv)
```
5. Accorder l'accès de votre application à votre Key Vault
```
az role assignment create --role "Key Vault Secrets User" --assignee "<principalId>" --scope $KEYVAULT
```
6. [Déployer](#Déploiement) l'application